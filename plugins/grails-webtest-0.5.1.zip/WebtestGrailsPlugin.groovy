
class WebtestGrailsPlugin {
	def version = "0.5.1"
	def dependsOn = [:] 
	def title = "A plug-in that provides functional testing for Grails using Canoo Web Test"
	def author = "Dierk Koenig"
	def authorEmail = "dierk.koenig at canoo.com"
	def description = title
}
